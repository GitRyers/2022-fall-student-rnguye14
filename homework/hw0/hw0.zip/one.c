//Ryan Nguyen
//rnguye14

#include <stdio.h>

int main() {
  printf("The first prize goes to Jennifer.");

  return 0;
}

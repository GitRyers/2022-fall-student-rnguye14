//Ryan Nguyen
//rnguye14

#include <stdio.h>

int main() {
  printf("The second prize goes to Gongqi.");

  return 0;
}

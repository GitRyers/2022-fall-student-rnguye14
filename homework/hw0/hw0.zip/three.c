//Ryan Nguyen
//rnguye14

#include <stdio.h>

int main() {
  printf("The third prize goes to Pat.");

  return 0;
}
